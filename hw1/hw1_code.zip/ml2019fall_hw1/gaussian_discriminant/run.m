% mu: 2x1 matrix
% Sigma: 2x2 matrix
% phi: a number

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Line', 1);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Line (one side)', 2);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Parabolic', 3);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Hyperbola', 4);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Two parallel lines.', 5);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Circle', 6);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'Ellipsoid', 7);

mu0 = _;
Sigma0 = _;
mu1 = _;
Sigma1 = _;
phi = _;
plot_ex1(mu0, Sigma0, mu1, Sigma1, phi, 'No boundary', 8);
